/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Watermelon extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("watermelon-a", "./Watermelon/costumes/watermelon-a.svg", {
        x: 40.13434982299805,
        y: 27.860475540161133
      }),
      new Costume("watermelon-b", "./Watermelon/costumes/watermelon-b.svg", {
        x: 23.5,
        y: 28.5
      }),
      new Costume("watermelon-c", "./Watermelon/costumes/watermelon-c.svg", {
        x: 21.5,
        y: 16
      })
    ];

    this.sounds = [new Sound("Bite", "./Watermelon/sounds/Bite.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "message1" },
        this.whenIReceiveMessage1
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    this.costume = "watermelon-a";
    /* TODO: Implement videoSensing_setVideoTransparency */ null;
    while (true) {
      this.createClone();
      yield;
    }
  }

  *startAsClone() {
    this.goto(this.mouse.x, this.mouse.y);
  }

  *whenKeySpacePressed() {
    this.visible = true;
    while (true) {
      if (/* TODO: Implement videoSensing_videoOn */ null > 50) {
        this.costume = "watermelon-c";
        this.stage.vars.food += 1;
        this.broadcast("message1");
        while (true) {
          this.y += -10;
          yield;
        }
      }
      yield;
    }
  }

  *whenIReceiveMessage1() {
    yield* this.wait(1);
    this.costume = "watermelon-a";
    this.deleteThisClone();
  }

  *whenGreenFlagClicked2() {}
}
